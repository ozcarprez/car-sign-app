
import dynamic from 'next/dynamic';
import { useRef } from 'react';

const SignaturePad = dynamic(() => import('react-signature-canvas'), { ssr: false });

export default function Home() {
  const sigPadRef = useRef();

  return (
    <div style={{ padding: 20 }}>
      <h1>Contrato de Compraventa</h1>
      <form>
        <label>Nombre del vendedor:</label>
        <input type="text" name="vendedor" /><br /><br />
        <label>Marca del auto:</label>
        <input type="text" name="marca" /><br /><br />
        <p>Firma del vendedor:</p>
        <SignaturePad ref={sigPadRef} canvasProps={{ width: 300, height: 100, className: 'sigCanvas' }} />
      </form>
    </div>
  );
}
